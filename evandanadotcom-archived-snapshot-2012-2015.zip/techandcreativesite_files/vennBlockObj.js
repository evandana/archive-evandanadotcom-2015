/*
c1 = developer
c2 = designer
c3 = active leader

category: [benefit, technology, position]
circle:   [c1, c2, c3]
skill:    scale 1-10 (only for technology)
ref:      link/id to reference
*/


var venn = [
	upperLeft = {
		vennItem: 'circle1',
		textClass: 'c1',
		title: 'Developer'
	},
	upperRight = {
		vennItem: 'circle2',
		textClass: 'c2',
		title: 'Designer'
	},
	lower = {
		vennItem: 'circle3',
		textClass: 'c3',
		title: 'Active Leader'
	}
];

var vennBlocks = new Array(
	// TECHNOLOGY
	{
		title:        'JavaScript',
		category:     'technology',
		circle:       'c1',
		skill:        '8',
		description:  'jQuery, Backbone, Highcharts, D3, Modernizr',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	
	{
		title:        'AngularJS',
		category:     'technology',
		circle:       'c1',
		skill:        '7',
		description:  'Custom directives, filters, and load sequence',
		links:        [ {title: "", ref: "", image: ""} ]
	},

	{
		title:        'Grunt',
		category:     'technology',
		circle:       'c1',
		skill:        '8',
		description:  'Copy, Concat, Min (& ngAnnotate)',
		links:        [ {title: "", ref: "", image: ""} ]
	},
                           
	{
		title:        'PHP',
		category:     'technology',
		circle:       'c1',
		skill:        '6',
		description:  'PHP as OOP, Cake',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'HTML',
		category:     'technology',
		circle:       'c1',
		skill:        '7',
		description:  'HTML5, semantic',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'Java',
		category:     'technology',
		circle:       'c1',
		skill:        '3',
		description:  'poi.apache.org: MS Word and Excel',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'Ruby (on Rails)',
		category:     'technology',
		circle:       'c1',
		skill:        '3',
		description:  'Heroku, Cucumber',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'Version Control',
		category:     'technology',
		circle:       'c1',
		skill:        '3',
		description:  'SVN, Git',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'CSS',
		category:     'technology',
		circle:       'c1 c2',
		skill:        '7',
		description:  'CSS3, LESS, Responsive',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'Mobile',
		category:     'technology',
		circle:       'c1 c2',
		skill:        '4',
		description:  'Responsive design, Light-weight',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'Adobe CS',
		category:     'technology',
		circle:       'c2',
		skill:        '8',
		description:  'Ai, Psd, InD: Batch processes, Scripting, &amp; Illustrations',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'Wireframing',
		category:     'technology',
		circle:       'c2',
		skill:        '4',
		description:  'PPT, Ai, Psd, Sketching',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'Sketching/Rendering',
		category:     'technology',
		circle:       'c2',
		skill:        '6',
		description:  'Quick and clear visual communication',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'Spinning Certified',
		category:     'technology',
		circle:       'c3',
		skill:        '7',
		description:  'Spin instructor certification',
		links:        [ {title: "", ref: "", image: ""} ]
	},
	{
		title:        'CPR / First Aid',
		category:     'technology',
		circle:       'c3',
		skill:        '5',
		description:  'Certified in CPR and First Aid',
		links:        [ {title: "", ref: "", image: ""} ]
	},

	// POSITIONS
    {
        title:        'Senior UI Developer',
        category:     'position',
        circle:       'c1 c3',
        skill:        '',
        description:  'Sapient Global Markets',
        links:        [ {title: "", ref: "#seniorjavascriptuideveloper", image: ""} ]
    },
	{
		title:        'UI Developer',
		category:     'position',
		circle:       'c1',
		skill:        '',
		description:  'Putnam Investments',
		links:        [ {title: "", ref: "#javascriptuideveloper", image: ""} ]
	},
	{
		title:        'UX Developer / Designer',
		category:     'position',
		circle:       'c1 c2',
		skill:        '',
		description:  'Innerscope Research Inc.',
		links:        [ {title: "", ref: "#userexperiencedeveloperdesigner", image: ""} ]
	},
	{
		title:        'Web Developer',
		category:     'position',
		circle:       'c1 c2',
		skill:        '',
		description:  'EC Boston',
		links:        [ {title: "", ref: "#webdeveloper", image: ""} ]
	},
	{
		title:        'Process Engineer',
		category:     'position',
		circle:       'c1',
		skill:        '',
		description:  'Crimson Life Sciences',
		links:        [ {title: "", ref: "#processengineer", image: ""} ]
	},
	{
		title:        'Collateral Graphic Designer',
		category:     'position',
		circle:       'c1 c2',
		skill:        '',
		description:  'Reebok: adidas International',
		links:        [ {title: "", ref: "#graphicdesignerprocessengineer", image: ""} ]
	},/*
	{
		title:        'Industrial Designer',
		category:     'position',
		circle:       'c1 c2',
		skill:        '',
		description:  'Swing Ltd.',
		links:        [ {title: "", ref: "", image: ""} ]
	},*/
	{
		title:        'Co-leader of NP BOS',
		category:     'position',
		circle:       'c3',
		skill:        '',
		description:  'November Project',
		links:        [ {title: "", ref: "#coleaderofnovemberprojectsbostontribe", image: ""} ]
	},
	{
		title:        'Crew Captain',
		category:     'position',
		circle:       'c3',
		skill:        '',
		description:  'CLIF Bar and Co.',
		links:        [ {title: "", ref: "#crewcaptainambassadorforclifbarco", image: ""} ]
	},
	{
		title:        'Webmaster of TMIRCE',
		category:     'position',
		circle:       'c1 c2 c3',
		skill:        '',
		description:  'The Most Informal Running Club Ever',
		links:        [ {title: "", ref: "#tmircewebsite", image: ""} ]
	},
	{
		title:        'Co-Leader of TMIRCE',
		category:     'position',
		circle:       'c3',
		skill:        '',
		description:  'The Most Informal Running Club Ever',
		links:        [ {title: "", ref: "#tmircewebsite", image: ""} ]
	},
	{
		title:        'Spin Instructor',
		category:     'position',
		circle:       'c3',
		skill:        '',
		description:  'Beacon Hill Athletic Clubs',
		links:        [ {title: "", ref: "#spininstructor", image: ""} ]
	},
	{
		title:        'Pan-Mass Challenge',
		category:     'position',
		circle:       'c3',
		skill:        '',
		description:  'Raised &gt;$20,000 for cancer research',
		links:        [ {title: "", ref: "#panmasschallenge", image: ""} ]
	},

	// BENEFITS: what can I do with those skills to benefit an employer

	// WEBSITES??

	// HIDDEN IN index.php
	{
		title:        'Creative Thinker',
		category:     'benefit',
		circle:       'c2',
		skill:        '8',
		description:  'some details here',
		links:        [ {title: "", ref: "", image: ""} ]
	}
);

