function generateVennBlocks() {
	// common selectors
	var vennBlockContainer = $('#vennBlockContainer'),
		techContainer = $('#technologiesContainer');

	vennBlockContainer.toggleClass('container', true);
	techContainer.find('#technologies').toggleClass('tickMarks_10', true);

	var replaceMap = {
		id:       '{{id}}',
		classes:  '{{classes}}',
		title:    '{{title}}',
		description:  '{{description}}'
	}

	function replaceByMap(template, block) {
		// template = "string"
		// block = {obj}
		template = template.replace(replaceMap.id, block.id);
		template = template.replace(replaceMap.classes, block.category + " " + block.circle);
		template = template.replace(replaceMap.title, block.title);
		template = template.replace(replaceMap.description, block.description);
		return template;
	}

	var mapElementIdToObjIndex = {};

	// get template
	var pathRef = (!location.href.match(/venndiagram/)) ? '../evandana/sandbox/d3/venndiagram/' : '';
	var template = $.get(pathRef + 'templates/vennBlocks.html', function(data) {
		var i = vennBlocks.length;
		while (i--) {
			var block = vennBlocks[i];
			// convert id from title
			block.id = "vennBlock_" + block.title.toLowerCase().replace(/ /g,'');
			mapElementIdToObjIndex[block.id] = i;
			// feed values into template
			//console.log(block.links[0]);
			var element = replaceByMap(data, block),

			element = $(element);

			//element.click(function () { console.log(':' + block.links[0].ref + ':'); });

			switch(block.circle)
			{
			case 'c1':
			  element.attr('class', 'c1 color1');
			  break;
			case 'c2':
			  element.attr('class', 'c2 color2');
			  break;
			case 'c3':
			  element.attr('class', 'c3 color3');
			  break;
			case 'c1 c2':
			  element.attr('class', 'c1 c2 color12');
			  break;
			case 'c2 c3':
			  element.attr('class', 'c2 c3 color23');
			  break;
			case 'c1 c3':
			  element.attr('class', 'c1 c3 color13');
			  break;
			case 'c1 c2 c3':
			  element.attr('class', 'c1 c2 c3 color123');
			  break;
			default:
			  // do nothing
			}			


			switch(block.category)
			{
			case 'position':
			  element.attr('title', "Jump to '" + block.title + "' in resume");
			  element.toggleClass('half-third', true).toggleClass('column', true);
			  element.click(function () {
			  	location = vennBlocks[mapElementIdToObjIndex[$(this)[0].id]].links[0].ref;
			  });
			  vennBlockContainer.find('#positions ul').prepend(element)
			  break;
			case 'benefit':
			  vennBlockContainer.find('#benefits ul').prepend(element);
			  break;
			case 'technology':
			  element.attr('title', block.description);
			  element.append('<div class="horizBar opacity_20" style="width:' + block.skill + '0.5%;">&nbsp</div>');
			  techContainer.find('#technologies ul').prepend(element);
			  break;
			default:
			  // do nothing
			}
		}
	});

	return vennBlockContainer;
}