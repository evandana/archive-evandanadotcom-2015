
$(document).ready(function() {

	/* Tray Item Link Generation
	================================================== */

//	alert();
	
	var tray = $('div.tray');

	var xml = '';

	tray.each(function(i) {

		//Get all tray item links 
		var trayItemLink = $(this).find('> div > a.trayItemLink');
		
		// create rollover/click var
		var clickedOnRollover = false
		var imageBeforeRollover = '';
		var elementID = '';
		
		// create text area vars
		var textDivID = '';
		
		trayItemLink.mouseover(function(e) {
			elementID = getId($(this));
			textDivID = elementID.replace(/image__/i,'desc__');
			var imagePath = getImagePath($(this));
			descriptionText = document.getElementById('desc__'+imagePath.replace(/.*\//g,'').replace(/\..*/,'')).innerHTML;
			
			imageBeforeRollover = document.getElementById(elementID).src;
			
			//uncomment below for rollout to return to previous image			clickedOnRollover = false;
			
			swapImage(elementID,imagePath);
			
			//document.getElementById(elementID).attr('onClick') = 'http://innerscoperesearch.com/drupal';
			
			//alert(imagePath.replace('','').substring(0,-4));
			
			document.getElementById(textDivID).dispay = 'block';
			document.getElementById(textDivID).innerHTML = descriptionText;
			if (descriptionText.length > 2 ) {
				$(textDivID).animate({height:'7px'},2000);
			} else {
				$(textDivID).animate({height:'0px'},"easeOutSine",2000);
			}
		});
		
		// uncomment below function for mouseout to return target image to pre-rollover
// 		trayItemLink.mouseout(function(e) {
// 			var elementID = getId($(this));
// 			var imagePath = imageBeforeRollover;
// 			
// 			if (clickedOnRollover == false) {
// 				// do stuff
// 				swapImage(elementID,imagePath);
// 			} else {	
// 				// do nothing
// 				clickedOnRollover = true;
// 			}
// 		});
		
// 		trayItemLink.click(function(e) {
// 			var elementID = getId($(this));
// 			var imagePath = getImagePath($(this));
// 			
// 			swapImage(elementID,imagePath);
// 
// 			clickedOnRollover = true;
// 		});
		
		
		
	});
});

function getId(selfItem) {	
	return selfItem.parent().parent().parent().parent().find('> .imagesArea img.resizeNeeded').attr('id');	
}

function getImagePath(selfItem) {
	return selfItem.find('img').attr('src').replace(/\/sm\//i,'/bg/');			
}

function swapImage(elementID,imagePath) {
	document.getElementById(elementID).src = imagePath;
}

//onclick="document.getElementById('image__<?php echo str_replace(' ', '_', $item->subtitle); ?>').src='<?php echo $iniPath; ?>assets/images/bg/<?php echo $project->image; ?>'; var clicked=true;" onmouseover="document.getElementById('image__<?php echo str_replace(' ', '_', $item->subtitle); ?>').src='<?php echo $iniPath; ?>assets/images/bg/<?php echo $project->image; ?>';" onmouseout="image_mouseout()"