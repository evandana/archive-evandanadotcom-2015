var windowWidth = window.innerWidth,
    w = getSvgWidth(),
    h = w/2.1,
    animationDuration = 700,
    growthScale = 1.3,
    centerMovementScale = 0.8,
    textMovementScale = .2,
    r_init = w/4,
    r_big = w/2.1;

var pos = {
	c1: {
		x: 3*w/10,
		y: h/5,
		r: r_init,
        tx: 3*w/10,
        ty: h/5,
		init: {
			x: 3*w/10,
			y: h/5,
			r: r_init
		}
	},
	c2: {
		x: w-3*w/10,
		y: h/5,
		r: r_init*0.8,
        tx: w-3*w/10,
        ty: h/5,
		init: {
			x: w-3*w/10,
			y: h/5,
			r: r_init*0.8
		}
	},
	c3: {
		x: w/2,
		y: h-h/5,
		r: r_init*0.6,
        tx: w/2,
        ty: h-h/5,
		init: {
			x: w/2,
			y: h-h/5,
			r: r_init*0.6
		}
	}
};


var svg = d3.select('#svgContainer').append("svg:svg")
	.attr('id', 'vennDiagram')
    .attr("width", w)
    .attr("height", h);

var defs = svg.append("svg:defs");

function calcCircleCenter() {
    var mid = [0 , 0];
    mid[0] = pos.c1.x + (pos.c2.x - pos.c1.x)/2;
    mid[1] = pos.c1.y + (pos.c3.y - pos.c1.y)/2;
    return mid;
}
var circleCenter = calcCircleCenter();

function getCirclesFromClasses(classes) {
	if (!!classes) {
		var circles = {
            active: [],
            inactive: []
        };
		var i = venn.length; // from vennBlockObj.js
		while (i--) {
			if (classes.indexOf(venn[i].vennItem) > -1) {
				circles.active.push(venn[i]);
			} else {
                circles.inactive.push(venn[i]);
            }
		}
		return circles;
	} else {
		return [];
	}
}

function mouseOverClipping(d) {
	var circles = getCirclesFromClasses(d3.select(this).attr('class')),
		thisCenter = [],
		centerTranslate = {};
	if (!!circles && circles.active.length > 0) {
		var i = circles.active.length; // from vennBlockObj.js
		while (i--) {
			//console.log(circles.active[i].vennItem);
            thisCenter = [
                pos[circles.active[i].textClass].x,
                pos[circles.active[i].textClass].y
            ];
            if (thisCenter[0] === pos[circles.active[i].textClass].init.x && 
                thisCenter[1] === pos[circles.active[i].textClass].init.y) {

                centerTranslate = {
                    x: thisCenter[0] - (circleCenter[0] - thisCenter[0]) * centerMovementScale * growthScale,
                    y: thisCenter[1] - (circleCenter[1] - thisCenter[1]) * centerMovementScale * growthScale,
                    tx: thisCenter[0] - (circleCenter[0] - thisCenter[0]) * textMovementScale,
                    ty: thisCenter[1] - (circleCenter[1] - thisCenter[1]) * textMovementScale
                };
                pos[circles.active[i].textClass].x = centerTranslate.x;
                pos[circles.active[i].textClass].y = centerTranslate.y;
                pos[circles.active[i].textClass].tx = centerTranslate.tx;
                pos[circles.active[i].textClass].ty = centerTranslate.ty;
                pos[circles.active[i].textClass].r = r_big;
            }
		}
	}
    if (!!circles && circles.inactive.length > 0) {
        var i = circles.inactive.length; // from vennBlockObj.js
        while (i--) {
            pos[circles.inactive[i].textClass].x = pos[circles.inactive[i].textClass].init.x;
            pos[circles.inactive[i].textClass].y = pos[circles.inactive[i].textClass].init.y;
            pos[circles.inactive[i].textClass].tx = pos[circles.inactive[i].textClass].init.x;
            pos[circles.inactive[i].textClass].ty = pos[circles.inactive[i].textClass].init.y;
            pos[circles.inactive[i].textClass].r = pos[circles.inactive[i].textClass].init.r;
        }
    }
	updateCircles(animationDuration);
}
function mouseOutClipping() {
}


function createCircles(animationDuration) {
	var filter1 = defs.append('svg:filter')
		.attr("id", "filter1")
		.attr("dx", 280)
		.attr("dy", 180);
    filter1.append("svg:feGaussianBlur")
      	.attr("in", "SourceAlpha")
      	.attr("stdDeviation", "2");
    filter1.append("svg:feOffset")
        .attr("dx", "2")
        .attr("dy", "2")
        .attr("result", "offset");
    var feMerge = filter1.append("feMerge");
    feMerge.append("feMergeNode");
    feMerge.append("feMergeNode")
        .attr("in", "SourceGraphic");

	defs.append("svg:clipPath")
	    .attr("id", venn[0].vennItem)
	    .attr("class", "clipPath")
	  .append("svg:circle")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("cx", pos.c1.x)
	    .attr("cy", pos.c1.y)
	    .attr("r", pos.c1.r)
	    .attr("transform", "translate(10,10, 10)");
	
	defs.append("svg:clipPath")
	    .attr("id", venn[1].vennItem)
	    .attr("class", "clipPath")
	  .append("svg:circle")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("cx", pos.c2.x)
	    .attr("cy", pos.c2.y)
	    .attr("r", pos.c2.r);
	
	defs.append("svg:clipPath")
	    .attr("id", venn[2].vennItem)
	    .attr("class", "clipPath")
	  .append("svg:circle")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("cx", pos.c3.x)
	    .attr("cy", pos.c3.y)
	    .attr("r", pos.c3.r);
	
	// upper left
	svg.append("svg:rect")
	  .attr("class", "vennItem " + venn[0].vennItem)
	    .attr("clip-path", "url(#circle1)")
	    .attr("width", w)
	    .attr("height", h)
	    .style("fill", "#0E53A7");
	
	// upper right
	svg.append("svg:rect")
	  .attr("class", "vennItem " + venn[1].vennItem)
	    .attr("clip-path", "url(#circle2)")
	    .attr("width", w)
	    .attr("height", h)
	    .style("fill", "#FFC700");
	
	// bottom
	svg.append("svg:rect")
	  .attr("class", "vennItem " + venn[2].vennItem)
	    .attr("clip-path", "url(#circle3)")
	    .attr("width", w)
	    .attr("height", h)
	    .style("fill", "#FF5C00");
	
	
	svg.append("svg:g")
	  .attr("class", "vennItem circle1 circle2")
	    .attr("clip-path", "url(#circle1)")
	  .append("svg:rect")
	    .attr("clip-path", "url(#circle2)")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("width", w)
	    .attr("height", h)
	    .style("fill", "#a7aD74");
	
	svg.append("svg:g")
	  .attr("class", "vennItem circle2 circle3")
	    .attr("clip-path", "url(#circle2)")
	  .append("svg:rect")
	    .attr("clip-path", "url(#circle3)")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("width", w)
	    .attr("height", h)
	    .style("fill", "#FFb230");
	
	svg.append("svg:g")
	  .attr("class", "vennItem circle1 circle3")
	    .attr("clip-path", "url(#circle3)")
	  .append("svg:rect")
	    .attr("clip-path", "url(#circle1)")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("width", w)
	    .attr("height", h)
	    .style("fill", "#a77874");
	
	// center
	svg.append("svg:g")
	  	.attr("class", "vennItem circle1 circle2 circle3")
	    .attr("clip-path", "url(#circle3)")
	  .append("svg:g")
	    .attr("clip-path", "url(#circle2)")
	  .append("svg:rect")
	    .attr("clip-path", "url(#circle1)")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("width", w)
	    .attr("height", h)
	    .style("fill", "#b98");
	
	svg.append("text")
		.attr("id", "c1title")
		.attr("class", "vennItemTitle circle1")
	    .attr("x", pos.c1.x)
	    .attr("y", pos.c1.y)
		.attr("dy", ".3em")
        .attr("font-size", w/20 + "px")
	    .attr("text-anchor", "middle")
        .attr("filter", "url(#filter1)")
	    .text(venn[0].title);
	
	svg.append("text")
		.attr("id", "c2title")
		.attr("class", "vennItemTitle circle2")
	    .attr("x", pos.c2.x)
	    .attr("y", pos.c2.y)
		.attr("dy", ".3em")
        .attr("font-size", w/20 + "px")
	    .attr("text-anchor", "middle")
        .attr("filter", "url(#filter1)")
	    .text(venn[1].title);
	
	svg.append("text")
		.attr("id", "c3title")
		.attr("class", "vennItemTitle circle3")
	    .attr("x", pos.c3.x)
	    .attr("y", pos.c3.y)
		.attr("dy", ".3em")
        .attr("font-size", w/20 + "px")
	    .attr("text-anchor", "middle")
        .attr("filter", "url(#filter1)")
	    .text(venn[2].title);
	    
	d3.selectAll(".vennItem.circle1, .vennItem.circle2, .vennItem.circle3")
	    .on("mouseover", mouseOverClipping)
	    .on("mouseout", mouseOutClipping);
	d3.selectAll(".vennItemTitle.circle1, .vennItemTitle.circle2, .vennItemTitle.circle3")
	    .on("mouseover", mouseOverClipping)
	    .on("mouseout", mouseOutClipping);

    return {defs: defs, svg: svg};
}

function updateCircles(animationDuration) {
	d3.select("#" + venn[0].vennItem + " circle")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("cx", pos.c1.x)
	    .attr("cy", pos.c1.y)
	    .attr("r", pos.c1.r);
	    
	d3.select("#" + venn[1].vennItem + " circle")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("cx", pos.c2.x)
	    .attr("cy", pos.c2.y)
	    .attr("r", pos.c2.r);
	
	d3.select("#" + venn[2].vennItem + " circle")
	  	.transition()
	  	.duration(animationDuration)
	    .attr("cx", pos.c3.x)
	    .attr("cy", pos.c3.y)
	    .attr("r", pos.c3.r);

    d3.select("text#c1title")
        .transition()
        .duration(animationDuration)
        .attr("x", pos.c1.tx)
        .attr("y", pos.c1.ty)

    d3.select("text#c2title")
        .transition()
        .duration(animationDuration)
        .attr("x", pos.c2.tx)
        .attr("y", pos.c2.ty)

    d3.select("text#c3title")
        .transition()
        .duration(animationDuration)
        .attr("x", pos.c3.tx)
        .attr("y", pos.c3.ty)

    return {defs: defs, svg: svg};
}

createCircles(animationDuration);

// set initial state 
mouseOverClipping.call($(".vennItem.circle1")[0]);

$(window).resize(function () {
    var newWindowWidth = this.innerWidth,
        oldWindowWidth = windowWidth; // referenced from top of file
    var newWB = getWidthBucket(newWindowWidth),
        oldWB = getWidthBucket(oldWindowWidth);
    var crossedThreshold = (newWB === oldWB) ? false : true ;

    if (crossedThreshold) {
        redraw();
    }
    windowWidth = newWindowWidth;
});

function redraw() {
    d3.select('#svgContainer svg').remove();
    /* TODO: clean this up! */
    /* start of sloppy repeating code */
    w = getSvgWidth();
    h = w/2.1;
    r_init = w/4;
    r_big = w/2.1;
    pos = {
        c1: {
            x: 3*w/10,
            y: h/5,
            r: r_init,
            tx: 3*w/10,
            ty: h/5,
            init: {
                x: 3*w/10,
                y: h/5,
                r: r_init
            }
        },
        c2: {
            x: w-3*w/10,
            y: h/5,
            r: r_init*0.8,
            tx: w-3*w/10,
            ty: h/5,
            init: {
                x: w-3*w/10,
                y: h/5,
                r: r_init*0.8
            }
        },
        c3: {
            x: w/2,
            y: h-h/5,
            r: r_init*0.6,
            tx: w/2,
            ty: h-h/5,
            init: {
                x: w/2,
                y: h-h/5,
                r: r_init*0.6
            }
        }
    };
    svg = d3.select('#svgContainer').append("svg:svg")
        .attr('id', 'vennDiagram')
        .attr("width", w)
        .attr("height", h);
    /* end of sloppy repeating code */
    defs = svg.append("svg:defs");
    circleCenter = calcCircleCenter();
    createCircles(animationDuration);  
    $('.vennItem').mouseover(vennItemMouseOver);
    // if mobile
    if (is_touch_device()) {
        $('.vennItemTitle').click(vennItemMouseOver);
    }

    // TODO: move to one reference in script.js
    $('#vennLegend').css('max-height', h+20 + "px")
    var hOffset = -15;
    if (getWidthBucket(window.innerWidth) < 3) {
    	hOffset = 0;
    }
    $('#vennLegend .fadeOutBottom').css('top', h+hOffset  + "px");

    //TODO: move this to script.js
    adjustHeightOfVennBlocks();

}
function getWidthBucket(width) {
    if (width>=960) {
      // largest size
        return 3;
    } else if (width>=768) {
        return 2
    } else if (width>=480) {
        return 1;
    } else {
        // smallest size
        return 0;
    }
}

function getSvgWidth() {
    var windowWidth = window.innerWidth,
        widthBucket = getWidthBucket(windowWidth);
    switch(widthBucket)
    {
    case 3:
      return 620;
    case 2:
      return 492;
    case 1:
      return 420;
    case 0:
      return 300;
    default:
      return 300;
    }
}
