$(document).ready(function() {
  // Handler for .ready() called.

	generateVennBlocks();
	$('#vennLegend').append('<' + introMessage.el + ' class="' + introMessage.class + '">' + introMessage.text + '</' +introMessage.el+ '>');

	// BIND EVENTS
	// bind touch for circles
	//bindTouchVennItem('.vennItem');

	$('.vennItem').mouseover(vennItemMouseOver);
	// if mobile
	if (is_touch_device()) {
		$('.vennItemTitle').click(vennItemMouseOver);
	}

	// start off with designer boxes showing
	var startPos = function () {
		$($('.vennItem.circle1')[0]).trigger('mouseover');
	};
	// needs a delay so the blocks can have loaded before mouseover is triggered
	var start = setTimeout(startPos, 1000);

});

var introMessage = {
	el: 'h5',
	class: 'intro',
	text: 'Touch the circles to show relevant information.',
	show: true
}


function adjustHeightOfVennBlocks() {
	var els = $('#vennBlockContainer #positions ul li.showBlock'),
		even = els.filter(":even"),
		odd = els.filter(":odd");
	els.css('height', ''); // undo height so it can be properly reset
	even.css('clear', 'both').css('margin-left', '');
	odd.css('clear', '').css('margin-left', '5px');


	var i = 0;
	while (i+1 < els.length) {
		var e1 = $(els[i]),
			e2 = $(els[i+1]),
			h1 = e1.height(),
			h2 = e2.height(),
			rowHeightMax = h1 > h2 ? h1 : h2; 
		e1.height(rowHeightMax);
		e2.height(rowHeightMax);
		i += 2
	}
	
}

function vennItemMouseOver() {
	// if intro message is not yet hidden, hide it
	if (introMessage.show) { 
		introMessage.show = false;
		$('#vennLegend ' + introMessage.el + '.' + introMessage.class).remove(); 
	}
	
	// get class of the ui element, using different methods for svg vs dom
	var classStr = $(this).attr('class').baseVal || $(this).attr('class');
	var legendTitle = "";
	var list = {
		hide: [],
		show: []
	};
	$(venn).each(function () {
		if (classStr.indexOf(this.vennItem) != -1) {
			list.show.push(this.textClass);
			legendTitle += legendTitle.length>0 ? " &amp; " + this.title : this.title;
		} else {
			list.hide.push(this.textClass);
		}
	});
	if (list.hide.length > 0) {
		$('#positions .' + list.hide.join(', #positions .')).toggleClass('showBlock', false);
		$('#technologies .' + list.hide.join(', #technologies .')).toggleClass('showBlock', false);
	}
	if (list.show.length > 0) {
		$('#positions .' + list.show.join(', #positions .')).toggleClass('showBlock', true);
		$('#technologies .' + list.show.join(', #technologies .')).toggleClass('showBlock', true);
	}
	$('#legendTitle').html(legendTitle);
	
	adjustHeightOfVennBlocks();

    $('#vennLegend').css('max-height', h+20 + "px")
    var hOffset = -15;
    if (getWidthBucket(window.innerWidth) < 3) {
    	hOffset = 0;
    }
    $('#vennLegend .fadeOutBottom').css('top', h+hOffset  + "px");
}

function is_touch_device() {
  return !!('ontouchstart' in window) // works on most browsers 
      || !!('onmsgesturechange' in window); // works on ie10
};
